import '../base_model.dart';

class WineEditModel extends BaseModel{

}